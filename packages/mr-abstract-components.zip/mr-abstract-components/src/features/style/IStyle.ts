// IStyle interface definition

export interface IStyle {
  color: string;
  borderColor?: string;
  borderWidth?: number;
  glow?: string;
  glowIntensity?: number;
}
