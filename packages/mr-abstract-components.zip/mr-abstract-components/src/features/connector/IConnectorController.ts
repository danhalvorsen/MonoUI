import { ISystemController } from "../abstractions/ISystemController.js";

export interface IConnectorController extends ISystemController { }
