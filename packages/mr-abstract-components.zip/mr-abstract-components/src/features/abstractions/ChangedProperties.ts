
export type ChangedProperties = Map<string, any>;
