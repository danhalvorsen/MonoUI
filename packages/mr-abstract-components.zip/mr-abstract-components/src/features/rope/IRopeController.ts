import { ISystemController } from '../abstractions/ISystemController';
// import { ISystemControllerConfiguration } from '../abstractions/SystemController/ISystemControllerConfiguration';
import { ISystemControllerConfiguration } from '../abstractions/ISystemControllerConfiguration';

export interface IRopeControllerConfiguration {}
export interface IRopeController extends ISystemController{
    
    configuration: IRopeControllerConfiguration;
    
    c1: ISystemControllerConfiguration;
}
