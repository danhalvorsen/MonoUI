import { IVisualObjectConfiguration } from '../canvas/IVisualObjectConfiguration.js';

export interface IRopeVisualConfiguration extends IVisualObjectConfiguration {

    id:string;
 }
