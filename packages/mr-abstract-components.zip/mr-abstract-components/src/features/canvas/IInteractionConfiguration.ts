export interface IInteractionConfiguration {
  selected?: boolean;
  enabled?: boolean;
  isDraggable?: boolean;
  visible?: boolean;
  zIndex?: number;
}
