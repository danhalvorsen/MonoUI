
// Re-export commonly used types for convenience
export type { IVisualStyle } from "./features/style/IVisualStyle.js";
 
