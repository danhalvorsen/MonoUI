// packages/mr-abstract-components/src/visualObjects/coordinate-systems/snap/SnapEngine.ts
import { Vector2 } from "@my-graphics/math";
import type { ISnapConfiguration } from "./ISnapConfiguration.js";
import type { ISnapRule } from "./SnapRules.js";
import type { SnapHit } from "./SnapHit.js";
import { GridSnapRule } from "./GridSnapRule.js";
import { AxisSnapRule}  from "../snap/AxisSnapRule.js"
import { CustomPointsSnapRule } from "./CustomPointsSnapRule.js";
 


export class SnapEngine {
  private rules: ISnapRule[];
  private cfg: ISnapConfiguration;

  constructor(cfg: ISnapConfiguration, rules?: ISnapRule[]) {
    this.cfg = { ...cfg };
    this.rules = rules ?? [new GridSnapRule(), new AxisSnapRule(), new CustomPointsSnapRule()];
  }

  updateConfig(patch: Partial<ISnapConfiguration>): void {
    this.cfg = { ...this.cfg, ...patch };
  }

  get config(): Readonly<ISnapConfiguration> { return this.cfg; }

  /** best hit or null */
  find(p: Vector2): SnapHit | null {
    if (!this.cfg.enabled) return null;
    let best: SnapHit | null = null;
    for (const r of this.rules) {
      const hit = r.test(p, this.cfg);
      if (hit && (!best || hit.distance < best.distance)) best = hit;
    }
    return best;
  }

  /** snapped point or original */
  snap(p: Vector2): Vector2 {
    return this.find(p)?.point ?? p;
  }

  shouldSnap(p: Vector2): boolean {
    return this.find(p) !== null;
  }
}