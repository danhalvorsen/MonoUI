import { Vector2 } from "@my-graphics/math";
import type { ISnapConfiguration } from "./ISnapConfiguration.js";
import { SnapHit } from "./SnapHit.js";

export interface ISnapRule {
  readonly id: string;
  /** Return the best snap for this rule or null if not applicable */
  test(p: Vector2, cfg: ISnapConfiguration): SnapHit | null;
}

