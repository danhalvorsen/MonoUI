import { Vector2 } from "@my-graphics/math";


export type SnapHit = { point: Vector2; distance: number; rule: string; };
