import { Vector2 } from "@my-graphics/math";
import { ISnapConfiguration } from "./ISnapConfiguration.js";

export interface ISnapController {
  readonly config: Readonly<ISnapConfiguration>;
  enabled: boolean;

  setEnabled(enabled: boolean): void;
  updateSnapConfiguration(patch: Partial<ISnapConfiguration>): void;

  /** Returns snapped point or null if no rule matched within tolerances */
  findSnapPoint(position: Vector2): Vector2 | null;

  /** Quick check if any rule would snap this position */
  shouldSnap(position: Vector2): boolean;
}