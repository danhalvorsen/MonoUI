import { Vector2 } from "@my-graphics/math";
import { ISnapConfiguration } from "./ISnapConfiguration.js";
import { ISnapRule } from "./SnapRules.js";
import { SnapHit } from "./SnapHit.js";

export class AxisSnapRule implements ISnapRule {
  readonly id = "axis";
  test(p: Vector2, cfg: ISnapConfiguration): SnapHit | null {
    if (!cfg.enabled || !cfg.snapToAxis) return null;
    const tol = cfg.axisSnapTolerance;
    let best: SnapHit | null = null;

    if (Math.abs(p.x) <= tol) best = { point: new Vector2(0, p.y), distance: Math.abs(p.x), rule: this.id };
    if (Math.abs(p.y) <= tol) {
      const hit = { point: new Vector2(p.x, 0), distance: Math.abs(p.y), rule: this.id };
      if (!best || hit.distance < best.distance) best = hit;
    }
    return best;
  }
}
