import { Vector2 } from "@my-graphics/math";
import type { ISnapConfiguration } from "./ISnapConfiguration.js";
import type { ISnapRule } from "./SnapRules.js";
import type { SnapHit } from "./SnapHit.js";
import { AxisSnapRule } from "./AxisSnapRule.js";
import { GridSnapRule } from "./GridSnapRule.js";

export class CustomPointsSnapRule implements ISnapRule {
  readonly id = "custom-points";

  test(p: Vector2, cfg: ISnapConfiguration): SnapHit | null {
    if (!cfg.enabled || !cfg.snapToCustomPoints || cfg.customSnapPoints.length === 0) return null;

    const tol = cfg.customPointSnapTolerance;
    let best: SnapHit | null = null;

    for (const pt of cfg.customSnapPoints) {
      const dx = p.x - pt.x;
      const dy = p.y - pt.y;
      const d = Math.hypot(dx, dy);
      if (d <= tol && (!best || d < best.distance)) {
        best = { point: pt, distance: d, rule: this.id };
      }
    }
    return best;
  }
}

export class SnapEngine {
  private rules: ISnapRule[];
  private cfg: ISnapConfiguration;

  constructor(cfg: ISnapConfiguration, rules?: ISnapRule[]) {
    this.cfg = { ...cfg };
    this.rules = rules ?? [new GridSnapRule(), new AxisSnapRule(), new CustomPointsSnapRule()];
  }

  updateConfig(patch: Partial<ISnapConfiguration>): void {
    this.cfg = { ...this.cfg, ...patch };
  }

  get config(): Readonly<ISnapConfiguration> { return this.cfg; }

  find(p: Vector2): SnapHit | null {
    if (!this.cfg.enabled) return null;
    let best: SnapHit | null = null;
    for (const r of this.rules) {
      const hit = r.test(p, this.cfg);
      if (hit && (!best || hit.distance < best.distance)) best = hit;
    }
    return best;
  }

  snap(p: Vector2): Vector2 {
    return this.find(p)?.point ?? p;
  }

  shouldSnap(p: Vector2): boolean {
    return this.find(p) !== null;
  }
}