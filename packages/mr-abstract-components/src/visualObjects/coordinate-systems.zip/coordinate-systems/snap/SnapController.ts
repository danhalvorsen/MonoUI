 
const DEFAULTS: ISnapConfiguration = {
  enabled: true,

  snapToGrid: true,
  gridSize: 10,
  gridSnapTolerance: 6,

  snapToObjects: false,
  objectSnapTolerance: 6,

  snapToAxis: false,
  axisSnapTolerance: 6,

  snapToCustomPoints: false,
  customSnapPoints: [],
  customPointSnapTolerance: 6,

  showSnapIndicators: true,
  snapIndicatorColor: "#00aaff",
  snapIndicatorSize: 4,

  snapRadius: 8,
};

import { Vector2 } from "@my-graphics/math";
import type { ISnapConfiguration } from "./ISnapConfiguration.js";
import type { ISnapController } from "./ISnapController.js";
import { SnapEngine } from "./SnapEngine.js";

export class SnapController implements ISnapController {
  private engine: SnapEngine;

  constructor(initial: ISnapConfiguration) {
    this.engine = new SnapEngine(initial);
  }

  get config(): Readonly<ISnapConfiguration> { return this.engine.config; }
  get enabled(): boolean { return this.engine.config.enabled; }
  set enabled(v: boolean) { this.engine.updateConfig({ enabled: v }); }

  setEnabled(enabled: boolean): void { this.engine.updateConfig({ enabled }); }
  updateSnapConfiguration(patch: Partial<ISnapConfiguration>): void { this.engine.updateConfig(patch); }

  findSnapPoint(position: Vector2): Vector2 | null { return this.engine.find(position)?.point ?? null; }
  shouldSnap(position: Vector2): boolean { return this.engine.shouldSnap(position); }
}