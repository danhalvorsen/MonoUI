import { Vector2 } from "@my-graphics/math";
import type { ISnapConfiguration } from "./ISnapConfiguration.js";
import { SnapMath } from "./SnapMath.js";
import { ISnapRule } from "./SnapRules.js";
import { SnapHit } from "./SnapHit.js";

/** Grid snapping */

export class GridSnapRule implements ISnapRule {
  readonly id = "grid";
  test(p: Vector2, cfg: ISnapConfiguration): SnapHit | null {
    if (!cfg.enabled || !cfg.snapToGrid) return null;
    const snapped = SnapMath.snapVec2(p.x, p.y, cfg.gridSize);
    const d = SnapMath.dist(p, snapped);
    return d <= cfg.gridSnapTolerance ? { point: snapped, distance: d, rule: this.id } : null;
  }
}
