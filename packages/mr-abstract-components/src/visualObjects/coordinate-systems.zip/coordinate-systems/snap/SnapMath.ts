import { Vector2 } from "@my-graphics/math";

export class SnapMath {
  static snap(value: number, step: number): number {
    if (step <= 0 || !isFinite(step)) return value;
    const q = Math.round(value / step) * step;
    return Object.is(q, -0) ? 0 : q;
  }

  static snapVec2(x: number, y: number, step: number): Vector2 {
    return new Vector2(SnapMath.snap(x, step), SnapMath.snap(y, step));
  }

  static dist(a: Vector2, b: Vector2): number {
    const dx = a.x - b.x, dy = a.y - b.y;
    return Math.hypot(dx, dy);
  }
}