 
import { IReactiveControllerHost } from "../../../controllers/ReactiveControllerHost.js";
import { IGridFeature } from "./IGridFeature.js";

export interface IGridController extends IReactiveControllerHost<IGridController> {
    gridFeature: IGridFeature;
    enabled: boolean;
    setEnabled(enabled: boolean): void;
    updateGridConfiguration(config: Partial<IGridFeature>): void;
    snapToGrid(x: number, y: number): { x: number; y: number } | null;
}
