import { ReactiveControllerHost } from "../../../controllers/ReactiveControllerHost.js";
import { INode } from "../../../core/index.js";
import { IRenderContext } from "../../../core/IRenderContext.js";

export class VisualGridNode 
extends ReactiveControllerHost<VisualGridNode> 
implements VisualGridNode {

    id: string;

    constructor() {
        super();
        this.id = '';
    }
    draw(render: IRenderContext): void {
        throw new Error("Method not implemented.");
    }
    name?: string | undefined;
    parentId?: string | undefined;
    tags?: string[] | undefined;
    metadata?: Record<string, unknown> | undefined;
    children?: INode[] | undefined;
    accept?(v: { visit(n: INode): void; }): void {
        throw new Error("Method not implemented.");
    }
    SetHost?<THost>(host: any): void {
        throw new Error("Method not implemented.");
    }
    Get?<THost>() {
        throw new Error("Method not implemented.");
    }
    SetMetaData?(metadata: Record<string, unknown>): void {
        throw new Error("Method not implemented.");
    }
    GetMetaData?(): Record<string, unknown> {
        throw new Error("Method not implemented.");
    }
    hostConnected(): void {
        throw new Error("Method not implemented.");
    }
    hostDisconnected(): void {
        throw new Error("Method not implemented.");
    }
    hostUpdate?(): void {
        throw new Error("Method not implemented.");
    }
    hostUpdated?(): void {
        throw new Error("Method not implemented.");
    }
}