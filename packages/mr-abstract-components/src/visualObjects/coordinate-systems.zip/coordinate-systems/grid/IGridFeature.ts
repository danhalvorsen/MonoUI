import { Vector2 } from "@my-graphics/math";
import { IConfiguration } from "../../../IConfiguration.js";
import { VisualGridNode } from "./VisualGridNode.js";
 
 

export interface IGridFeature extends VisualGridNode {
    configuration: IConfiguration[];
    cellSize: number;
    spacing?: number;
    origin: Vector2;
    visible: boolean;
    gridColor?: string;
    lineWidth?: number;
    opacity?: number;
    gridType?: 'square' | 'hexagonal' | 'triangular';
    snapTolerance?: number;
    bounds?: { min: Vector2; max: Vector2; };
    snapToGrid(point: Vector2): Vector2;
    getNearestGridPoint(position: Vector2): Vector2;
    isWithinSnapDistance(point: Vector2): boolean;
    getGridLinesInBounds(bounds: { minX: number; maxX: number; minY: number; maxY: number; }): { horizontal: number[]; vertical: number[]; };
    worldToGrid(worldPos: Vector2): { row: number; col: number; };
    gridToWorld(row: number, col: number): Vector2;
}
