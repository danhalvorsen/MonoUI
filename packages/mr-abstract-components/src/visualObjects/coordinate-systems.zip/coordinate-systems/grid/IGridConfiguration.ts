import type { Vector2 } from "@my-graphics/math";

export interface IGridConfiguration {
  visible: boolean;
  cellSize: number;
  color: string;
  lineWidth: number;
  opacity: number;
  origin: Vector2;
  showMajorLines: boolean;
  majorLineSpacing: number;
  majorLineColor: string;
  majorLineWidth: number;
  showMinorLines: boolean;
  minorLineColor: string;
  minorLineWidth: number;
}
