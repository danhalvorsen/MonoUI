import { INode, IVisualAxis } from "mr-abstract-components";
import { Vector2 } from "@my-graphics/math";
import { IReactiveController } from "../../../controllers/IReactiveController.js";
import { IReactiveControllerHost } from "../../../controllers/ReactiveControllerHost.js";
import { BaseController } from "../../../controllers/reactiveControllers/BaseController.js";
import { INodeVisitor, IVisualNode } from "../../../core/index.js";
import { IVisualAxisConfiguration } from "./IVisualAxisConfiguration.js";


export class VisualAxis extends BaseController implements IVisualAxis {
    constructor(axis: IVisualNode, configuration: IVisualAxisConfiguration[]) {
        super();
        this.axis = axis;
        this.configuration = configuration;
    }
    SetId(id: string): void {
        throw new Error("Method not implemented.");
    }
    GetId():string {
        throw new Error("Method not implemented.");
    }
    GetName():string {
        throw new Error("Method not implemented.");
    }
    GetParent(): INode {
        throw new Error("Method not implemented.");
    }
    GetTags(): string[] {
        throw new Error("Method not implemented.");
    }
    GetMetadata(): Record<string, unknown> {
        throw new Error("Method not implemented.");
    }
    GetChildren(): INode[] {
        throw new Error("Method not implemented.");
    }
    visit(visitor: INodeVisitor): INode {
       throw new Error("Method not implemented.");
    }
    acceptVisitor(visitor: INode): INode {
        visitor.visit(this);
        return this.axis;
    }
    GetHost(): IReactiveControllerHost<INode> {
        throw new Error("Method not implemented.");
    }
    GetPosition(): Vector2;
    GetPosition(): Vector2;
    GetPosition(): import("@my-graphics/math").Vector2 {
        throw new Error("Method not implemented.");
    }
    SetPosition(): Vector2 {
        throw new Error("Method not implemented.");
    }
    SetDirection(direction: Vector2): void {
        throw new Error("Method not implemented.");
    }
    GetDirection(): Vector2 {
        throw new Error("Method not implemented.");
    }
    SetScale(scale: Vector2): void {
        throw new Error("Method not implemented.");
    }
    GetScale(): Vector2 {
        throw new Error("Method not implemented.");
    }
    SetTranslate(offset: Vector2): void {
        throw new Error("Method not implemented.");
    }
    GetTranslate(): Vector2 {
        throw new Error("Method not implemented.");
    }
    SetRotation(rotation: Vector2): void {
        throw new Error("Method not implemented.");
    }
    GetRotation(): Vector2 {
        throw new Error("Method not implemented.");
    }
    AddReactiveController(controller: IReactiveController): void {
        throw new Error("Method not implemented.");
    }
    RemoveReactiveController(controller: IReactiveController): void {
        throw new Error("Method not implemented.");
    }
    id: string = "";
    name?: string = "";
    parentId?: string = "";
    tags: string[] = [];
    metadata: Record<string, unknown> = {};
    children: INode[] = [];
    accept?(visitor: INodeVisitor): void {
        throw new Error("Method not implemented.");
    }
    SetHost?<THost>(host: any): void {
        throw new Error("Method not implemented.");
    }
    GetReactiveControllerHost(): IReactiveControllerHost<INode> {
        return this.GetReactiveControllerHost();
    }
    SetMetaData?(metadata: Record<string, unknown>): void {
        this.metadata = metadata;
        33
    }

    GetMetaData?(): Record<string, unknown> {
        throw new Error("Method not implemented."); 
    }

    axis: IVisualNode;
    configuration: IVisualAxisConfiguration[];

    render(context: CanvasRenderingContext2D): void {
        throw new Error("Method not implemented."); 
    }
}
