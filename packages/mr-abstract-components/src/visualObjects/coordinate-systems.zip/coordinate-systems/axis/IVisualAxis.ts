// visualObjects/coordinate-systems/grid/axis/VisualAxis.ts
import type { INode, INodeVisitor, IVisualNode } from "../../../core/index.js";
import { BaseController } from "../../../controllers/reactiveControllers/BaseController.js";
import type { IVisualAxisConfiguration } from "./IVisualAxisConfiguration.js";

export class VisualAxis extends BaseController implements INode {
  id: string;
  name?: string;
  children: INode[] = [];

  constructor(
    id: string,
    private readonly axis: IVisualNode,
    private readonly configuration: IVisualAxisConfiguration[]
  ) {
    super();
    this.id = id;
  }

  accept(visitor: INodeVisitor): void {
    visitor.visit(this);
  }

  // If your IVisualNode has draw(render) and is itself a node, it will be
  // picked up by RenderVisitor via children:
  // this.children = [axis];
}
