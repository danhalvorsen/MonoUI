// import { ISystemController } from "../../../controllers/ISystemController.js";
import { IVisualAxisConfiguration } from "./IVisualAxisConfiguration.js";
import { IVisualObject } from "../../../core/IVisualObject.js";
import { IReactiveControllerHost } from "../../../controllers/ReactiveControllerHost.js";
 
export interface IAxisController extends IReactiveControllerHost<IAxisController> {
    configuration: IVisualAxisConfiguration;
    axis: IVisualObject;
}

