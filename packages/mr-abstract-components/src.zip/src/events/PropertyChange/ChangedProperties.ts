
export interface IChangedProperties {
  [key: string]: { oldValue: unknown; newValue: unknown };
}   