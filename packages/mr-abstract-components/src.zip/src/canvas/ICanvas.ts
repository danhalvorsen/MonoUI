
export interface ICanvas {
  readonly element: HTMLCanvasElement;
  readonly context: CanvasRenderingContext2D;
}
