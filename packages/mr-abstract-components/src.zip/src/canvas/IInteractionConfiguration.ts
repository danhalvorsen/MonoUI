
export interface IInteractionConfiguration {
  selected?: boolean;
  enabled?: boolean;
  draggable?: boolean;
  visible?: boolean;
  zIndex?: number;
}
