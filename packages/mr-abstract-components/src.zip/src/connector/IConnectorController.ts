import { ISystemController } from "src/index.js";

export interface IConnectorController extends ISystemController  { }
