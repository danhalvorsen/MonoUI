export interface IConfiguration {
    id: string;
    configValues?: Record<string, unknown>; // Flexible configuration storage
}

