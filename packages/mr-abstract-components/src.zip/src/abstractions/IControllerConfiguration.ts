import { IConfiguration } from "./IConfiguration.js";

export interface IControllerConfiguration extends IConfiguration {
    
}
