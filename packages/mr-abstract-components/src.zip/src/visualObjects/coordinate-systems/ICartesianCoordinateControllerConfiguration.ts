import { IAxisConfiguration } from "./grid/axis/IAxisConfiguration.js";
import { IGridConfiguration } from "./grid/IGridConfiguration.js";
import { ISnapConfiguration } from "./snap/ISnapConfiguration.js";
import { IVisualObjectConfiguration } from "../../world/visualObjects/IVisualObjectConfiguration.js";

export interface ICartesianCoordinateControllerConfiguration extends IVisualObjectConfiguration {
  xAxisConfig: IAxisConfiguration;
  yAxisConfig: IAxisConfiguration;
  gridConfig: IGridConfiguration;
  snapConfig: ISnapConfiguration;
  canvasWidth: number;
  canvasHeight: number;
  bounds: { xMin: number; xMax: number; yMin: number; yMax: number; };
}
