import { INode } from "../../../core/nodes/INode.js";
 
export interface IVisualSnapNode extends INode  {
    snapToGrid: boolean;
    snapToOrigin: boolean;
    snapToAxis: boolean;
    snapToCenter: boolean;
    snapToConnector: boolean;
    snapToSnapFeature: boolean;
}
