import { Vector2 } from "@my-graphics/math";
export interface ISnapConfiguration {
  enabled: boolean;

  // Grid
  snapToGrid: boolean;
  gridSize: number;               // <-- added (needed for grid snapping)
  gridSnapTolerance: number;

  // Objects
  snapToObjects: boolean;
  objectSnapTolerance: number;

  // Axes / origin / centerlines
  snapToAxis: boolean;
  axisSnapTolerance: number;

  // Custom points
  snapToCustomPoints: boolean;
  customSnapPoints: Vector2[];
  customPointSnapTolerance: number;

  // UI
  showSnapIndicators: boolean;
  snapIndicatorColor: string;
  snapIndicatorSize: number;

  // General radius (optional visual affordance)
  snapRadius: number;
}
