import { IGridController } from "./grid/IGridController.js";
import { ISnapController } from "./snap/ISnapController.js";
import { IVisualAxis } from "./grid/axis/IVisualAxis.js";
import { ICartesianCoordinateControllerConfiguration } from "./ICartesianCoordinateControllerConfiguration.js";
import { IReactiveControllerHost } from "../../controllers/ReactiveControllerHost.js";
import { IReactiveController } from "../../controllers/IReactiveController.js";
import { BaseControllerHost } from "../../controllers/reactiveControllers/BaseControllerHost.js";

export interface ICartesianCoordinateController extends IReactiveControllerHost<ICartesianCoordinateController> {
    configuration: ICartesianCoordinateControllerConfiguration;
    xAxisControllerHost: IReactiveControllerHost<IVisualAxis>;
    yAxisControllerHost: IReactiveControllerHost<IVisualAxis>;
    gridControllerHost: IReactiveControllerHost<IGridController>;
    snapControllerHost: IReactiveControllerHost<ISnapController>;
}

export class CartesianCoordinateController implements ICartesianCoordinateController {
    xAxisControllerHost: IReactiveControllerHost<IVisualAxis>;
    yAxisControllerHost: IReactiveControllerHost<IVisualAxis>;
    gridControllerHost: IReactiveControllerHost<IGridController>;
    snapControllerHost: IReactiveControllerHost<ISnapController>;
    configuration: ICartesianCoordinateControllerConfiguration;
    updateComplete: Promise<boolean>;

    constructor(configuration: ICartesianCoordinateControllerConfiguration) {
        this.configuration = configuration;
        this.xAxisControllerHost = new BaseControllerHost<IVisualAxis>(null as unknown as IVisualAxis);
        this.yAxisControllerHost = new BaseControllerHost<IVisualAxis>(null as unknown as IVisualAxis);
        this.gridControllerHost = new BaseControllerHost<IGridController>(null as unknown as IGridController);
        this.snapControllerHost = new BaseControllerHost<ISnapController>(null as unknown as ISnapController);
        this.updateComplete = Promise.resolve(true);
    }

    private handleControllerAction(
        action: "addController" | "removeController",
        controller: IReactiveController
    ): void {
        const type = typeof (controller as any).getType === "function"
            ? (controller as any).getType()
            : undefined;

        switch (type) {
            case "XAxis":
                this.xAxisControllerHost?.[action]?.(controller);
                break;
            case "YAxis":
                this.yAxisControllerHost?.[action]?.(controller);
                break;
            case "Grid":
                this.gridControllerHost?.[action]?.(controller);
                break;
            case "Snap":
                this.snapControllerHost?.[action]?.(controller);
                break;
            default:
                console.warn(`Unknown controller type for ${action}:`, type);
        }
    }
    addController(controller: IReactiveController): void {
       this.xAxisControllerHost?.addController?.(controller);
    }

    removeController(controller: IReactiveController): void {
        this.xAxisControllerHost?.removeController?.(controller);
    }

    requestUpdate(): void {
        // Implement update logic if needed
        // For now, just a placeholder
    }
}