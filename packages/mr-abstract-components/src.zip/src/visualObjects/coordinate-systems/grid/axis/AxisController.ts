import { ReactiveControllerHost } from "../../../../controllers/ReactiveControllerHost.js";
import { IVisualObject } from "../../../../core/IVisualObject.js";
import { IAxisController } from "./IAxisController.js";
import { IVisualAxisConfiguration } from "./IVisualAxisConfiguration.js";


export class AxisController extends ReactiveControllerHost<IAxisController> {
    configuration: IVisualAxisConfiguration;
    axis: IVisualObject;

    constructor(configuration: IVisualAxisConfiguration, axis: IVisualObject) {
        super();
        this.configuration = configuration;
        this.axis = axis;
    }
}
