import { IVisualObjectConfiguration } from "../../../../world/visualObjects/IVisualObjectConfiguration.js";

export interface IVisualAxisConfiguration extends IVisualObjectConfiguration {
    showAxis: boolean;
    color: string;
    lineWidth: number;
    showTicks: boolean;
    tickSpacing: number;
    showLabels: boolean;
}
