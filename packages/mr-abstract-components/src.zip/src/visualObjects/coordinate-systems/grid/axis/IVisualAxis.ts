 
 
import { INode } from "../../../../core/index.js";
import { IVisualNode } from "../../../../core/nodes/IVisualNode.js";
import { IConfiguration } from "../../../../IConfiguration.js";
 
 
 
export interface IVisualAxis extends INode {
    axis: IVisualNode
    configuration: IConfiguration; // Ensure this matches IVisualNode's configuration type


    render(context: CanvasRenderingContext2D): void;
}


