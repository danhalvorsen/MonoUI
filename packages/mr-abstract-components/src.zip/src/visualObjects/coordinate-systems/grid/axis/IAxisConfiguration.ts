import { Vector2 } from "@my-graphics/math";

export interface IAxisConfiguration {
  showAxis: boolean;
  color: string;
  lineWidth: number;
  opacity: number;
  showTicks: boolean;
  tickSize: number;
  tickSpacing: number;
  showLabels: boolean;
  labelFont: string;
  labelColor: string;
  showOrigin: boolean;
  originSize: number;
  originColor: string;
  range: Vector2;
}
