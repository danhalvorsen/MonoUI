import { IVisualObjectConfiguration } from "../IVisualObjectConfiguration.js";
export interface IRopeVisualConfiguration extends IVisualObjectConfiguration {
    id:string;
}
