// import { ISystemController } from "../../../controllers/ISystemController.js";
export interface IConnectorController /* extends ISystemController */  { }
