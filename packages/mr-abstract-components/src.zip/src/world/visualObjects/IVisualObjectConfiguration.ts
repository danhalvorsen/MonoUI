import { IVisualStyle } from "../../style/IStyle.js";
import { IInteractionConfiguration } from "../../canvas/IInteractionConfiguration.js";
import { IConnector } from "./connector/IConnector.js";

export interface IVisualObjectConfiguration {

}
