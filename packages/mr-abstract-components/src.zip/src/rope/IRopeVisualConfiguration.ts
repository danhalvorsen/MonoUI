import {  IVisualObjectConfiguration} from "src/index.js";

export interface IRopeVisualConfiguration extends IVisualObjectConfiguration {

    id:string;
 }
