 
import { Vector2 } from "@my-graphics/math";
import { IReactiveController } from "../../../controllers/IReactiveController.js";
import { IReactiveControllerHost } from "../../../controllers/ReactiveControllerHost.js";
import type { INode, Metadata } from "../INode.js";
import { INodeVisitor } from "./INodeVisitor.js";

export abstract class NodeBase implements INode {
  visit(visitor: INodeVisitor): INode {
    throw new Error("Method not implemented.");
  }
  children: INode[] = [];
  SetId(id: string): void {
    throw new Error("Method not implemented.");
  }
  GetId(): string {
    throw new Error("Method not implemented.");
  }
  getRouteCondition(): string {
    throw new Error("Method not implemented.");
  }
  GetName(): string {
    throw new Error("Method not implemented.");
  }
  GetParent(): INode {
    throw new Error("Method not implemented.");
  }
  GetTags(): string[] {
    throw new Error("Method not implemented.");
  }
  GetMetadata(): Metadata {
    throw new Error("Method not implemented.");
  }
  GetChildren(): Array<INode> {
    throw new Error("Method not implemented.");
  }
  acceptVisitor(visitor: INodeVisitor): INode {
    throw new Error("Method not implemented.");
  }
  SetHost(): IReactiveControllerHost<INode> {
    throw new Error("Method not implemented.");
  }
  SetMetaData?(metadata: Metadata): void {
    throw new Error("Method not implemented.");
  }
  GetMetaData?(): Metadata {
    throw new Error("Method not implemented.");
  }
  GetPosition(): Vector2;
  GetPosition(): Vector2;
  GetPosition(): Vector2 {
    throw new Error("Method not implemented.");
  }
  SVGTextPositioningElement(position: Vector2): void {
    throw new Error("Method not implemented.");
  }
  SetDirection(direction: Vector2): void {
    throw new Error("Method not implemented.");
  }
  GetDirection(): Vector2 {
    throw new Error("Method not implemented.");
  }
  setSourceMapsEnabled(scale: Vector2): void {
    throw new Error("Method not implemented.");
  }
  getDefaultAutoSelectFamilyAttemptTimeout(): Vector2 {
    throw new Error("Method not implemented.");
  }
  SetTranslate(offset: Vector2): void {
    throw new Error("Method not implemented.");
  }
  GetTranslate(): Vector2 {
    throw new Error("Method not implemented.");
  }
  SetRotation(rotation: Vector2): void {
    throw new Error("Method not implemented.");
  }
  GetRotation(): Vector2 {
    throw new Error("Method not implemented.");
  }
  AddReactiveController(controller: IReactiveController): void {
    throw new Error("Method not implemented.");
  }
  GetReactiveControllerHost(): IReactiveControllerHost<INode> {
    throw new Error("Method not implemented.");
  }
  RemoveReactiveController(controller: IReactiveController): void {
    throw new Error("Method not implemented.");
  }
  addController(controller: IReactiveController): void {
    throw new Error("Method not implemented.");
  }
  removeController(controller: IReactiveController): void {
    throw new Error("Method not implemented.");
  }
  requestUpdate(): void {
    throw new Error("Method not implemented.");
  }
  updateComplete: Promise<boolean>;
  
}
