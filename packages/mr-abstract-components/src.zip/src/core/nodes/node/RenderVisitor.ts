import { IRenderContext } from "../../IRenderContext.js";
import { INode } from "../INode.js";
import { IVisualNode } from "../IVisualNode.js";
import { INodeVisitor } from "./INodeVisitor.js";
 
//Todo: As a method
function isVisualNode(node: INode): node is IVisualNode {
    return typeof (node as IVisualNode).draw === "function";
}

export class RenderVisitor implements INodeVisitor {
    constructor(private render: IRenderContext) {
        if (!this.render) {
            throw new Error("Render context is required for RenderVisitor");
        }           
    }
    visit(node: INodeVisitor): void {
        if (isVisualNode(node)) {
            node.draw(this.render);
        }
        node.children?.forEach(child => {
            if (child && typeof child.accept === "function") {
                child.accept(this);
            }
        });
    }
}
