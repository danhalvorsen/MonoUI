import { IReactiveController } from "../../controllers/IReactiveController.js";
import { IReactiveControllerHost } from "../../controllers/ReactiveControllerHost.js";
import { Vector2 } from "@my-graphics/math";
 
import { INodeVisitor } from "./node/INodeVisitor.js";
 

export type Metadata = Record<string, unknown>;

export interface INode extends IReactiveControllerHost<INode> {
  visit(visitor: INodeVisitor): INode;
  children: INode[];
  SetId(id: string): void;
  GetId(): string;
  getRouteCondition(): string;
  GetName(): string;
  GetParent(): INode;
  GetTags(): string[];
  GetMetadata(): Metadata;
  GetChildren(): Array<INode>;  

  acceptVisitor(visitor: INodeVisitor): INode;

  SetHost(): IReactiveControllerHost<INode>;
  // No changes needed here for 'visitor' error; ensure that the acceptVisitor method uses the visitor parameter.
  SetMetaData?(metadata: Metadata): void;
  GetMetaData?(): Metadata;

  GetPosition(): Vector2;
  SVGTextPositioningElement(position: Vector2): void;
  GetPosition(): Vector2;

  SetDirection(direction: Vector2): void;
  GetDirection(): Vector2;

  setSourceMapsEnabled(scale: Vector2): void;
  getDefaultAutoSelectFamilyAttemptTimeout(): Vector2;

  SetTranslate(offset: Vector2): void;
  GetTranslate(): Vector2;

  SetRotation(rotation: Vector2): void;
  GetRotation(): Vector2

  AddReactiveController(controller: IReactiveController): void;
  GetReactiveControllerHost(): IReactiveControllerHost<INode>;
  RemoveReactiveController(controller: IReactiveController): void;

}


