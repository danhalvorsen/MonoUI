// apps/demo-node-canvas/src/main.ts
import { BaseVisualObject, Canvas2DRenderer } from 'mr-abstract-components';

export class DemoObject extends BaseVisualObject {
  color: string;

  constructor(id: string, color: string) {
    super(id);
    this.color = color;
    this.size = { width: 100, height: 100 };
  }

  draw(ctx: CanvasRenderingContext2D): void {
    ctx.fillStyle = this.color;
    ctx.fillRect(0, 0, this.size.width, this.size.height);
  }
}