// DemoObject.ts
import { Matrix as Matrix3 } from '@my-graphics/math';
import { BaseVisualObject } from 'mr-abstract-components';
export class DemoObject extends BaseVisualObject {
  rotation = 0;
  worldMatrix: Matrix3 = new Matrix3();

  constructor(id: string, color: string) {
    const config: IVisualObjectConfiguration = {
      id,
      visual: { style: { fill: color, stroke: '#000', strokeWidth: 2 } },
      interaction: { isDraggable: false },
      connectors: [],
    };
    super(id, config);
    this.size = { width: 100, height: 100 };
  }

  updateWorldMatrix(): void {
    this.worldMatrix
      .identity()
      .translate(this.position.x, this.position.y)
      .rotate(this.rotation);
  }

  draw(render: IRenderType): void {
    // Hvis du trenger egen spesialtegning, gjør det her
    // For eksempel: (Canvas2DRenderer vil uansett bruke config)
  }

  update(dt: number): void {
    // Oppdater animasjoner eller logikk her
  }

  render(ctx: CanvasRenderingContext2D | WebGLRenderingContext): void {
    // Evt. direkte tegning her
  }
}
